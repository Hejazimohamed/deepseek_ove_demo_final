﻿# updater.py

import json
import requests
import logging
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QMessageBox, QProgressDialog

class UpdateManager(QThread):
    update_available = pyqtSignal(str, str)  # إشارة للإصدار الجديد وسجل التغييرات
    update_error = pyqtSignal(str)  # إشارة للخطأ

    def __init__(self, current_version):
        super().__init__()
        self.current_version = current_version
        self.checker = UpdateChecker(current_version)
        self.applier = UpdateApplier()

    def check_for_updates(self):
        self.checker.update_available.connect(self.handle_check_result)
        self.checker.start()

    def handle_check_result(self, is_available, version, changelog):
        if is_available:
            self.update_available.emit(version, changelog)

    def start_update(self):
        self.applier.finished.connect(self.handle_update_result)
        self.applier.start()

    def handle_update_result(self, success):
        if not success:
            self.update_error.emit("فشل تنزيل التحديث")

class UpdateChecker(QThread):
    update_available = pyqtSignal(bool, str, str)  # حالة التحديث، الإصدار، سجل التغييرات

    def __init__(self, current_version):
        super().__init__()
        self.current_version = current_version

    def run(self):
        try:
            response = requests.get(
                "https://raw.githubusercontent.com/.../version.json",
                timeout=10
            )
            data = response.json()
            latest_version = data.get("version")
            changelog = data.get("changelog", "")

            is_newer = latest_version > self.current_version
            self.update_available.emit(is_newer, latest_version, changelog)
        except Exception as e:
            logging.error(f"فشل التحقق من التحديث: {e}")

class UpdateApplier(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(bool)

    def run(self):
        try:
            # كود تنزيل التحديث هنا
            self.finished.emit(True)
        except Exception as e:
            logging.error(f"فشل التحديث: {e}")
            self.finished.emit(False)