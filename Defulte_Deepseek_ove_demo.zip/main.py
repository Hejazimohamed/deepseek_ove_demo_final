import sys
import logging
from pathlib import Path
import tempfile
from PyQt5.QtWidgets import QApplication
from main_window import OCRMainWindow

# إعداد مسار آمن لتخزين سجل الأخطاء في مجلد مؤقت
log_path = Path(tempfile.gettempdir()) / "ocr_app_errors.log"
logging.basicConfig(
    filename=str(log_path),
    filemode="a",
    format="%(asctime)s [%(levelname)s]: %(message)s",
    level=logging.INFO
)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = OCRMainWindow()
    win.show()
    sys.exit(app.exec_())