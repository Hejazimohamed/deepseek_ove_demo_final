﻿# main_window.py

import sys
import os
import pytesseract
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QFileDialog, QTextEdit, QComboBox, QProgressBar,
    QMessageBox, QMenuBar, QAction, QDialog, QFormLayout
)
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PIL import Image
from updater import UpdateManager
from settings_manager import SettingsManager

class OCRMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = SettingsManager()
        self.init_ui()
        self.init_update_system()
        self.apply_settings()

    def init_ui(self):
        self.setWindowTitle("الذكي OCR")
        self.setMinimumSize(900, 600)

        menubar = self.menuBar()
        file_menu = menubar.addMenu("الملف")
        settings_menu = menubar.addMenu("الإعدادات")

        update_action = QAction("التحقق من التحديثات", self)
        update_action.triggered.connect(self.manual_update_check)
        settings_menu.addAction(update_action)

        central_widget = QWidget()
        main_layout = QVBoxLayout()

        self.image_preview = QLabel()
        self.image_preview.setAlignment(Qt.AlignCenter)
        self.text_output = QTextEdit()
        self.progress_bar = QProgressBar()

        btn_layout = QHBoxLayout()
        self.import_btn = QPushButton("استيراد صورة/PDF")
        self.process_btn = QPushButton("بدء المعالجة")

        btn_layout.addWidget(self.import_btn)
        btn_layout.addWidget(self.process_btn)

        main_layout.addWidget(self.image_preview)
        main_layout.addLayout(btn_layout)
        main_layout.addWidget(self.text_output)
        main_layout.addWidget(self.progress_bar)

        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self.import_btn.clicked.connect(self.import_file)
        self.process_btn.clicked.connect(self.start_ocr)

    def init_update_system(self):
        self.update_manager = UpdateManager("1.0.0")
        self.update_manager.update_available.connect(self.handle_update)
        self.update_manager.update_error.connect(self.show_update_error)

    def apply_settings(self):
        lang = self.settings.get('general', 'language', 'ar')
        theme = self.settings.get('general', 'theme', 'light')
        self.apply_theme(theme)

    def import_file(self):
        pass

    def start_ocr(self):
        pass

    def handle_update(self, new_version, changelog):
        msg = QMessageBox()
        msg.setWindowTitle("تحديث متوفر")
        msg.setText(
            f"الإصدار {new_version} متاح!\n\n"
            f"التغييرات:\n{changelog}"
        )
        msg.addButton("تحديث الآن", QMessageBox.AcceptRole)
        msg.addButton("لاحقًا", QMessageBox.RejectRole)

        if msg.exec_() == QMessageBox.AcceptRole:
            self.update_manager.start_update()

    def show_update_error(self, error):
        QMessageBox.warning(self, "خطأ", f"فشل التحقق من التحديثات:\n{error}")

    def manual_update_check(self):
        self.update_manager.check_for_updates()

    def apply_theme(self, theme_name):
        pass