﻿import sys
import logging
import traceback

# إعداد السجل لتسجيل جميع الأخطاء غير المتوقعة
logging.basicConfig(
    filename="ocr_app_errors.log",
    filemode="a",
    level=logging.ERROR,
    format="%(asctime)s [%(levelname)s]: %(message)s"
)

def handle_exception(exc_type, exc_value, exc_traceback):
    """تسجيل أي استثناء غير معالج"""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    logging.error("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))

# ربط handler بالنظام
sys.excepthook = handle_exception

# تسجيل رسائل PyQt (critical/warning/fatal)
try:
    from PyQt5.QtCore import qInstallMessageHandler
    from PyQt5.QtCore import QtMsgType

    def qt_message_handler(mode, context, message):
        if mode == QtMsgType.QtCriticalMsg:
            logging.error(f"QtCriticalMsg: {message}")
        elif mode == QtMsgType.QtWarningMsg:
            logging.warning(f"QtWarningMsg: {message}")
        elif mode == QtMsgType.QtFatalMsg:
            logging.error(f"QtFatalMsg: {message}")
        # يمكن تسجيل الرسائل العادية أيضًا لو أردت

    qInstallMessageHandler(qt_message_handler)
except Exception as e:
    logging.warning("qInstallMessageHandler غير مدعومة في هذا الإصدار أو حدث خطأ.")

from PyQt5.QtWidgets import QApplication
from main_window import OCRMainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = OCRMainWindow()
    win.show()
    sys.exit(app.exec_())
