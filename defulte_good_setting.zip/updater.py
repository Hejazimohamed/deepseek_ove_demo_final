
import json
import requests
import logging
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QMessageBox, QProgressDialog


class UpdateChecker(QThread):
    update_available = pyqtSignal(bool, str)

    def __init__(self, current_version):
        super().__init__()
        self.current_version = current_version
        self.latest_version = None
        self.changelog = ""

    def run(self):
        try:
            response = requests.get(
                "https://raw.githubusercontent.com/Hejazimohamed/ocr-update_final/main/version.json",
                timeout=10
            )
            data = response.json()
            self.latest_version = data.get("version")
            self.changelog = data.get("changelog", "")

            is_newer = self.latest_version > self.current_version
            self.update_available.emit(is_newer, self.changelog)
        except Exception as e:
            logging.error(f"فشل التحقق من التحديث: {e}")


class UpdateApplier(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(bool)

    def __init__(self, update_url):
        super().__init__()
        self.update_url = update_url

    def run(self):
        try:
            response = requests.get(self.update_url, stream=True)
            total_size = int(response.headers.get("content-length", 0))
            temp_path = "update_temp.zip"
            with open(temp_path, "wb") as f:
                downloaded = 0
                for data in response.iter_content(chunk_size=4096):
                    f.write(data)
                    downloaded += len(data)
                    self.progress.emit(int((downloaded / total_size) * 100))
            self.finished.emit(True)
        except Exception as e:
            logging.error(f"فشل التحديث: {e}")
            self.finished.emit(False)


def prompt_user_for_update(changelog, parent=None):
    msg = QMessageBox(parent)
    msg.setIcon(QMessageBox.Information)
    msg.setWindowTitle("تحديث متوفر")
    msg.setText("تحديث جديد متوفر!")
    msg.setInformativeText(f"سجل التغييرات:\n{changelog}\n\nهل تريد المتابعة بالتحديث؟")
    msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
    return msg.exec_() == QMessageBox.Yes
